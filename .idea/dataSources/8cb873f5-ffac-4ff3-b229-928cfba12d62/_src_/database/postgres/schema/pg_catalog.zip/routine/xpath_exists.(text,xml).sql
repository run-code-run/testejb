create function xpath_exists(text, xml) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])
$$;
